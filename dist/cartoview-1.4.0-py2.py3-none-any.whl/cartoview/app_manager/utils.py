# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from __future__ import print_function
from __future__ import division
from __future__ import absolute_import
from future import standard_library
standard_library.install_aliases()
from builtins import *
from builtins import object
from django.conf import settings
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404
from django.views.decorators.http import require_http_methods
from geonode.api.resourcebase_api import LayerResource
from geonode.maps.models import Map
from tastypie.serializers import Serializer
from cartoview.app_manager.models import AppInstance
import abc
from future.utils import with_metaclass


@require_http_methods([
    "GET",
])
def map_layers(request):
    map_id = request.GET.get('id', None)
    layer_type = request.GET.get('layer_type', None)
    if map_id:
        resource = LayerResource()
        serializer = Serializer()
        result = {}
        map_obj = get_object_or_404(Map, id=map_id)
        layers = map_obj.local_layers
        result['meta'] = {}
        result['meta']['limit'] = 1000
        result['meta']['next'] = None
        result['meta']['offset'] = 0
        result['meta']['previous'] = None
        result['meta']['total_count'] = len(layers)
        result['objects'] = []
        for layer in layers:
            bundle = resource.build_bundle(obj=layer, request=request)
            dehydrated_obj = resource.full_dehydrate(bundle)
            # TODO:Test this layer_type filter behavior
            if layer_type:
                qs = layer.attribute_set.filter(
                    attribute_type__icontains=layer_type)
                if qs.count() > 0:
                    dehydrated_obj.data.update(
                        {'layer_type': qs[0].attribute_type})
            else:
                qs = layer.attribute_set.get(attribute_type__contains="gml:")
                dehydrated_obj.data.update(
                    {'layer_type': qs.attribute_type})
            result['objects'].append(dehydrated_obj)
        data = serializer.serialize(result)
        return HttpResponse(data, content_type='application/json')
    else:
        return HttpResponse("not enough pramters", status=400)


class Thumbnail(with_metaclass(abc.ABCMeta, object)):
    @abc.abstractmethod
    def create_thumbnail(self):
        """Implement your thumbnail method"""
        pass


class AppsThumbnail(Thumbnail):
    def __init__(self, instance):
        self.instance = instance

    def create_thumbnail(self):
        instance = self.instance
        if not isinstance(instance, AppInstance):
            return
        elif (instance.thumbnail_url is not None or
              instance.thumbnail_url != "") and instance.map is not None:
            parent_app_thumbnail_url = instance.map.get_thumbnail_url()
            instance.thumbnail_url = parent_app_thumbnail_url
            instance.save()
