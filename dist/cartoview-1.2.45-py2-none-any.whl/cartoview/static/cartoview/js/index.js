/**
 * Created by kamal on 8/16/16.
 */

angular.module('cartoview.index', ['cartoview.base']);
angular.module('cartoview.index').config(function () {

});
