# -*- coding: utf-8 -*-
# WTF,what are you trying to do?? this code is useless
# import os
# os.environ['Path'] = r'C:\Cartoview\GDAL;'+ os.environ['Path']
# os.environ['GEOS_LIBRARY_PATH'] = r'C:\Cartoview\GDAL\geos_c.dll'
# os.environ['GDAL_LIBRARY_PATH'] = r'C:\Cartoview\GDAL\gdal111.dll'
